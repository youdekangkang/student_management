UI sketch desription

Log in page:
If the user has got the account,they only need to input their username and password.If not,they should click Register button to create an account.

Register page:
new user should input their username,password and choose they are students or teacher .After filling the table and click Create button,a new account created and go back to Log in page.

Catalog of course page:
If user is student:they can see the course name,teachers' name, planned amount of hours and syllabus download button.Student can click every course's name to know the brief information of the course The buttons at the bottom are used to switch the pages.
If users are teacher: there are two additional buttons,one is used to delete the course and another one is used to edit the course information.The Create button at the lower right corner is used to create new course.Both Edit and Create button will turn to course add page.
On the upper right corner,there is log out button and setting button which is a gear wheel.Clicking gear wheel takes to Setting page.

Setting page:
Used to reset the password.After clicking Change button will turn to log in page.

Course edit page:
Teacher can add or edit course in this page,upload button is used to upload the syllabus.Once click the Save button the information of course will be shown in the catalog of course page and go back to catalog of course page.

Admin page:
After administrators log in,they can see every users' name and user type,administrators also can change users'user type.For example,administrators can change student to teacher model or change teacher to student model.
 

 
